// This would be your Booking model (you can integrate it with a database like MySQL later)
class Booking {
    constructor(id, name, email, room, checkIn, checkOut) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.room = room;
        this.checkIn = checkIn;
        this.checkOut = checkOut;
    }
}

module.exports = Booking;
