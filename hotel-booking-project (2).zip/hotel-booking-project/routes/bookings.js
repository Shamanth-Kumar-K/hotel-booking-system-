// This file can contain API routes for bookings if you want to separate them
const express = require('express');
const router = express.Router();

// Dummy data for now
let bookings = [];

router.post('/', (req, res) => {
    const { name, email, room, checkIn, checkOut } = req.body;

    const newBooking = {
        id: bookings.length + 1,
        name,
        email,
        room,
        checkIn,
        checkOut,
    };

    bookings.push(newBooking);

    res.status(201).json({ bookingId: newBooking.id });
});

module.exports = router;
