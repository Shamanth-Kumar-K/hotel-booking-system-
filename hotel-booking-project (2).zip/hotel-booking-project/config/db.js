// config/db.js
const mysql = require('mysql2');

const db = mysql.createConnection({
    host: 'localhost', // change this to your MySQL host
    user: 'root', // your MySQL username
    password: 'YOUR PASSWORD', // your MySQL password
    database: 'hotel_booking', // the database name
});

db.connect((err) => {
    if (err) {
        console.error('Error connecting to the database:', err);
    } else {
        console.log('Connected to the MySQL database');
    }
});

module.exports = db;
